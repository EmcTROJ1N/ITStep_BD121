#pragma once

void init(char title[666], char header[666]);
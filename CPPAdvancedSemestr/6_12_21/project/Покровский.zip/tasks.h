#pragma once

void task_1();
void task_2();
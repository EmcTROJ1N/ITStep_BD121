#pragma once
#include <iostream>
#include <cmath>
#include <iomanip>   // для манипуляторов вывода setw(), setprecision()
#include "utils.h"
#include <string>
#include <time.h>
#include <cstdlib>

#define _USE_MATH_DEFINES

using namespace std;